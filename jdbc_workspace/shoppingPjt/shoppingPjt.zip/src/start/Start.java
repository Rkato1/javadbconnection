package start;

import kh.shopping.controller.ShoppingController;

public class Start {

	public static void main(String[] args) {
		ShoppingController shop = new ShoppingController();
		shop.main();
	}
}
